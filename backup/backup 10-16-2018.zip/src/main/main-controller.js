var app = angular.module('main');

app.controller('MainController', ['$scope', 'serviceHeaderShow', function ($scope, serviceHeaderShow) {
	// Functions
	$scope.parseContent = function () {
		finalStr = $scope.userInput;

		finalStr = finalStr.replace(/(?:\r\n|\r|\n)/g, "\\n");
		finalStr = finalStr.replace(/([\"])/g, "\\\"");
		finalStr = finalStr.replace(/([>])/g, "\\>");

		//finalStr = "new $scope.webElement(\"\",\n	\"\"" + finalStr + "\n),"

		finalStr = "new $scope.webElement(\"\",\n\t\t\t\t\t\t\"" + finalStr + "\"\n\t\t\t\t\t),"
		$scope.textAreaText = finalStr;

		document.getElementById("u").select();
		document.execCommand('copy');
	};

	// Class Definitions
	$scope.webElement = function (name, code) {
		this.name = name;
		this.code = code;

		this.updateTextArea = function () {
			$scope.textAreaText = this.code;
		}
	};

	// Variables
	$scope.textAreaText = "";
	$scope.userInput = "";
	$scope.windowShow = [true, false, false, false];

	// All Bookmarks.
	$scope.bookmarks = [
		new $scope.webElement("JS All Reference", "https://www.w3schools.com/jsref/default.asp"),
		new $scope.webElement("JS Array", "https://www.w3schools.com/jsref/jsref_obj_array.asp"),

		new $scope.webElement("CAR - Production", "https://atiam.train.army.mil/catalog/dashboard"),
		new $scope.webElement("TAG - Production", "https://atiam.train.army.mil/catalog/tag/home"),
		new $scope.webElement("MT2 - Production", "https://atiam.train.army.mil/mthp/"),

		new $scope.webElement("CAR - Test", "https://atiatest.train.army.mil/catalog/dashboard"),
		new $scope.webElement("TAG - Test", "https://atiatest.train.army.mil/catalog/tag/home"),
		new $scope.webElement("MT2 - Test", "https://atiatest.train.army.mil/mthp/"),

		new $scope.webElement("CAR - LocalHost", "http://localhost:8080/catalog/dashboard"),
		new $scope.webElement("TAG - LocalHost", "http://localhost:8080/catalog/tag/home"),
		new $scope.webElement("MT2 - LocalHost", "http://localhost:8080/catalog/mt2/"),
	];

	// ANGULARJS
	$scope.angular_dataStructures = [
		new $scope.webElement("Array",
			"x = [\n\t{Element},\n\t{Element},\n\t{... n}\n];"
		),
		new $scope.webElement("Objects",
			"myObj = {\n	x : \"hey\",\n	y : {\n		face : \"head\",\n		arm : \"leg\"\n	}\n};"
		),
		new $scope.webElement("For Loop",
			"for (var i = 0; i < x.length; i++) \n{\n\n}"
		),
		new $scope.webElement("Switch",
			"switch(x)\n{\n    case n:\n        code block\n        break;\n    default:\n        code block\n}"
		),
		new $scope.webElement("ng-repeat",
			"<div ng-repeat=\"x in modalLinks\"\> \n	<label\>{{x.[someVar]}}</label\><br /\>\n</div\>"
		),
	];

	$scope.angular_modulePieces = [
		new $scope.webElement("Routing",
			"<!DOCTYPE html\>\n<html\>\n<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js\"\></script\>\n<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular-route.js\"\></script\>\n\n<body ng-app=\"myApp\"\>\n\n<p\><a href=\"#/!\"\>Main</a\></p\>\n\n<a href=\"#!red\"\>Red</a\>\n<a href=\"#!green\"\>Green</a\>\n<a href=\"#!blue\"\>Blue</a\>\n\n<div ng-view\></div\>\n\n<script\>\nvar app = angular.module(\"myApp\", [\"ngRoute\"]);\napp.config(function($routeProvider) {\n    $routeProvider\n    .when(\"/\", {\n        templateUrl : \"main.htm\"\n    })\n    .when(\"/red\", {\n        templateUrl : \"red.htm\"\n    })\n    .when(\"/green\", {\n        templateUrl : \"green.htm\"\n    })\n    .when(\"/blue\", {\n        templateUrl : \"blue.htm\"\n    });\n});\n</script\>\n\n<p\>Click on the links to navigate to \"red.htm\", \"green.htm\", \"blue.htm\", or back to \"main.htm\"</p\>\n</body\>\n</html\>"
		),
		new $scope.webElement("Directives",
			"* Example of creating a new directive.\n\n<!DOCTYPE html\>\n<html\>\n<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js\"\></script\>\n<body ng-app=\"myApp\"\>\n\n<w3-test-directive\></w3-test-directive\>\n\n<script\>\nvar app = angular.module(\"myApp\", []);\napp.directive(\"w3TestDirective\", function() {\n    return {\n        template : \"<h1\>Made by a directive!</h1\>\"\n    };\n});\n</script\>\n\n</body\>\n</html\>\n\n* Four ways to invoke a directive: \n\nElement name: <w3-test-directive\></w3-test-\ndirective\>\nAttribute: <div w3-test-directive\></div\>\nClass: <div class=\"w3-test-directive\"\></div\>\nComment: <!-- directive: w3-test-directive --\>\n\nE,A,C,M are the restrict flag values.\n\n* Implementation:\n\nvar app = angular.module(\"myApp\", []);\napp.directive(\"w3TestDirective\", function() {\n    return {\n        restrict : \"A\",\n        template : \"<h1\>Made by a directive!</h1\>\"\n    };\n });"
		),
	];

	// HTML
	$scope.html_attributes = [
		new $scope.webElement("Introduction",
			"<!DOCTYPE html\>\n<html\>\n<head\>\n<title\>Page Title</title\>\n</head\>\n<body\>\n\n<h1\>My First Heading</h1\>\n<p\>My first paragraph.</p\>\n\n</body\>\n</html\>"
		),
		new $scope.webElement("Text-Decoration",
			"h1 {\n    text-decoration: overline;\n}\n\nh2 {\n    text-decoration: line-through;\n}\n\nh3 {\n    text-decoration: underline;\n}\n\nh3 {\n    text-decoration: underline overline;\n}"
		),

	];

	// CSS
	$scope.css_styles = [
		new $scope.webElement("Text-Decoration",
			"h1 {\n    text-decoration: overline;\n}\n\nh2 {\n    text-decoration: line-through;\n}\n\nh3 {\n    text-decoration: underline;\n}\n\nh3 {\n    text-decoration: underline overline;\n}"
		),
	];
}]);