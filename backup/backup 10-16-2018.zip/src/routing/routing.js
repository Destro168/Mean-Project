var app = angular.module('main');

app.config('MainController', ['$scope', function ($scope) {
    $routeProvider
        .when("/", {
            templateUrl: "bookmarks.html"
        })
        .when("/html", {
            templateUrl: "html.html"
        })
}]);