angular.
module('main').
component('converterComponent', {
    templateUrl: 'src/html-components/converter/converter.component.html',
    controller: function converterComponent($scope) {
        // Variables
        $scope.textAreaText = "";
        $scope.userInput = "";

        // Functions
        $scope.parseContent = function () {
            finalStr = $scope.userInput;

            finalStr = finalStr.replace(/(?:\r\n|\r|\n)/g, "\\n");
            finalStr = finalStr.replace(/([\"])/g, "\\\"");
            finalStr = finalStr.replace(/([>])/g, "\\>");

            // TODO, implement this format:
            //new this.webElement("JS All Reference", "https://www.w3schools.com/jsref/default.asp"),

            finalStr = "new this.webElement(\"\",\n\t\t\t\t\t\t\"" + finalStr + "\"\n\t\t\t\t\t),"
            $scope.textAreaText = finalStr;


            document.getElementById("u").select();
            document.execCommand('copy');
        };
    }
});
